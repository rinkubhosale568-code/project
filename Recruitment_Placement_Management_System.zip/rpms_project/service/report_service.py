from util.db_connection import Database
class ReportService:
    def candidates_by_technology(self): return Database.fetch_all("SELECT technology,COUNT(*) total FROM candidates GROUP BY technology ORDER BY total DESC")
    def open_jobs(self): return Database.fetch_all("SELECT j.job_id,j.title,c.name company_name,j.technology,j.openings,j.location,j.package_lpa,j.deadline FROM jobs j JOIN companies c ON c.company_id=j.company_id WHERE j.status='OPEN' ORDER BY deadline")
    def applications_by_status(self): return Database.fetch_all("SELECT status,COUNT(*) total FROM applications GROUP BY status")
    def company_placements(self): return Database.fetch_all("SELECT c.name company,COUNT(p.placement_id) placements FROM companies c LEFT JOIN placements p ON p.company_id=c.company_id AND p.joining_status='JOINED' GROUP BY c.company_id,c.name ORDER BY placements DESC")
    def placed_unplaced(self): return Database.fetch_all("SELECT c.candidate_id,c.name,c.technology,CASE WHEN EXISTS(SELECT 1 FROM placements p JOIN applications a ON a.application_id=p.application_id WHERE a.candidate_id=c.candidate_id AND p.joining_status='JOINED') THEN 'PLACED' ELSE 'UNPLACED' END placement_status FROM candidates c ORDER BY c.name")
