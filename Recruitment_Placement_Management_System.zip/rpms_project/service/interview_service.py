from util.db_connection import Database
from util.logger import logger
class InterviewService:
    def add(self,application_id,round_name,scheduled_at,mode,interviewer="",notes=""):
        iid=Database.execute("INSERT INTO interviews(application_id,round_name,scheduled_at,mode,interviewer,notes) VALUES(%s,%s,%s,%s,%s,%s)",(application_id,round_name,scheduled_at,mode,interviewer,notes)); logger.info("Interview scheduled: %s",iid); return iid
    def feedback(self,iid,technical,communication,remarks,result):
        Database.execute("UPDATE interviews SET technical_rating=%s,communication_rating=%s,remarks=%s,result=%s WHERE interview_id=%s",(technical,communication,remarks,result,iid))
    def all(self): return Database.fetch_all("SELECT i.*,c.name candidate_name,j.title job_title FROM interviews i JOIN applications a ON a.application_id=i.application_id JOIN candidates c ON c.candidate_id=a.candidate_id JOIN jobs j ON j.job_id=a.job_id ORDER BY scheduled_at DESC")
