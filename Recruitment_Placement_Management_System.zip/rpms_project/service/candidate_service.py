from dao.candidate_dao import CandidateDAO
from util.validators import percentage, non_negative_int, required
from util.logger import logger
class CandidateService:
    def __init__(self): self.dao=CandidateDAO()
    def add(self, data):
        data["name"]=required(data["name"],"Name"); data["email"]=required(data["email"],"Email"); data["mobile"]=required(data["mobile"],"Mobile")
        data["percentage"]=percentage(data["percentage"]); data["backlogs"]=non_negative_int(data.get("backlogs",0),"Backlogs")
        cid=self.dao.add_data if False else None
        from model.candidate import Candidate
        c=Candidate(**data); new_id=self.dao.add(c); logger.info("Candidate created: %s",new_id); return new_id
    def update(self, cid, data):
        data["percentage"]=percentage(data["percentage"]); data["backlogs"]=non_negative_int(data.get("backlogs",0),"Backlogs")
        from model.candidate import Candidate
        self.dao.update(cid, Candidate(**data)); logger.info("Candidate updated: %s",cid)
    def all(self): return self.dao.all()
    def search(self, keyword): return self.dao.search(keyword)
    def deactivate(self, cid): self.dao.deactivate(cid); logger.info("Candidate deactivated: %s",cid)
