from datetime import date
class EligibilityService:
    def check(self, candidate, job):
        reasons=[]
        if not candidate or not candidate.get("active"): reasons.append("Candidate is inactive or not found")
        if not job or job.get("status")!="OPEN": reasons.append("Job is not open")
        if job and job.get("deadline") and job["deadline"] < date.today(): reasons.append("Application deadline has passed")
        if candidate and job:
            if candidate["percentage"] < job["min_percentage"]: reasons.append(f"Percentage {candidate['percentage']} is below required {job['min_percentage']}%")
            if job.get("passing_year") and candidate["passing_year"] != job["passing_year"]: reasons.append(f"Passing year must be {job['passing_year']}")
            if candidate["backlogs"] > job["max_backlogs"]: reasons.append(f"Backlogs exceed maximum allowed ({job['max_backlogs']})")
            req=(job.get("technology") or "").lower(); tech=(candidate.get("technology") or "").lower(); skills=(candidate.get("skills") or "").lower()
            if req and req not in tech and req not in skills: reasons.append(f"Required technology/skill '{job['technology']}' not found in candidate profile")
        return {"eligible":not reasons,"reasons":reasons}
