from util.db_connection import Database
from util.logger import logger
class OfferService:
    def create(self,application_id,designation,package_lpa,offer_date,joining_date,status="PENDING"):
        oid=Database.execute("INSERT INTO offers(application_id,designation,package_lpa,offer_date,joining_date,status) VALUES(%s,%s,%s,%s,%s,%s)",(application_id,designation,package_lpa,offer_date,joining_date,status)); logger.info("Offer created: %s",oid); return oid
    def all(self): return Database.fetch_all("SELECT o.*,c.name candidate_name,j.title job_title,co.name company_name FROM offers o JOIN applications a ON a.application_id=o.application_id JOIN candidates c ON c.candidate_id=a.candidate_id JOIN jobs j ON j.job_id=a.job_id JOIN companies co ON co.company_id=j.company_id ORDER BY offer_id DESC")
