class Application:
    def __init__(self, candidate_id, job_id, status="APPLIED"):
        self.candidate_id=int(candidate_id); self.job_id=int(job_id); self.status=status
