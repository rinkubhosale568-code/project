from util.db_connection import Database
class ApplicationDAO:
    def exists(self, candidate_id, job_id): return Database.fetch_one("SELECT application_id FROM applications WHERE candidate_id=%s AND job_id=%s",(candidate_id,job_id)) is not None
    def add(self, candidate_id, job_id): return Database.execute("INSERT INTO applications(candidate_id,job_id) VALUES(%s,%s)",(candidate_id,job_id))
    def all(self): return Database.fetch_all("SELECT a.*,c.name candidate_name,j.title job_title,co.name company_name FROM applications a JOIN candidates c ON c.candidate_id=a.candidate_id JOIN jobs j ON j.job_id=a.job_id JOIN companies co ON co.company_id=j.company_id ORDER BY a.application_id DESC")
    def update_status(self, app_id, status): Database.execute("UPDATE applications SET status=%s WHERE application_id=%s",(status,app_id))
