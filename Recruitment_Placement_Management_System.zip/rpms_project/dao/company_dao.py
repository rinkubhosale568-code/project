from util.db_connection import Database
class CompanyDAO:
    def add(self, values): return Database.execute("INSERT INTO companies(name,industry,contact_person,email,phone,location,website) VALUES(%s,%s,%s,%s,%s,%s,%s)",values)
    def all(self): return Database.fetch_all("SELECT * FROM companies ORDER BY company_id DESC")
    def search(self, keyword): return Database.fetch_all("SELECT * FROM companies WHERE name LIKE %s OR industry LIKE %s",(f"%{keyword}%",f"%{keyword}%"))
