import os
from dotenv import load_dotenv
import mysql.connector
from mysql.connector import Error

load_dotenv()

class Database:
    @staticmethod
    def connect():
        return mysql.connector.connect(
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", "3306")),
            user=os.getenv("DB_USER", "root"),
            password=os.getenv("DB_PASSWORD", ""),
            database=os.getenv("DB_NAME", "rpms"),
        )

    @staticmethod
    def fetch_all(sql, params=()):
        conn = Database.connect()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute(sql, params)
            return cur.fetchall()
        finally:
            conn.close()

    @staticmethod
    def fetch_one(sql, params=()):
        rows = Database.fetch_all(sql, params)
        return rows[0] if rows else None


    @staticmethod
    def execute(sql, params=()):
        conn = Database.connect()
        try:
            cur = conn.cursor()
            cur.execute(sql, params)
            conn.commit()
            return cur.lastrowid
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
