CREATE DATABASE IF NOT EXISTS rpms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rpms;
CREATE TABLE IF NOT EXISTS candidates (
 candidate_id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, email VARCHAR(150) NOT NULL UNIQUE,
 mobile VARCHAR(20) NOT NULL UNIQUE, qualification VARCHAR(100) NOT NULL, percentage DECIMAL(5,2) NOT NULL,
 passing_year INT NOT NULL, technology VARCHAR(100) NOT NULL, skills TEXT, backlogs INT NOT NULL DEFAULT 0,
 active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CHECK (percentage BETWEEN 0 AND 100), CHECK (backlogs >= 0)
);
CREATE TABLE IF NOT EXISTS companies (
 company_id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(160) NOT NULL, industry VARCHAR(120), contact_person VARCHAR(120),
 email VARCHAR(150), phone VARCHAR(30), location VARCHAR(180), website VARCHAR(200), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS jobs (
 job_id INT AUTO_INCREMENT PRIMARY KEY, company_id INT NOT NULL, title VARCHAR(160) NOT NULL, technology VARCHAR(120) NOT NULL,
 openings INT NOT NULL, location VARCHAR(180), package_lpa DECIMAL(8,2), min_percentage DECIMAL(5,2) NOT NULL DEFAULT 0,
 passing_year INT NULL, max_backlogs INT NOT NULL DEFAULT 0, deadline DATE NULL, description TEXT,
 status ENUM('OPEN','CLOSED') NOT NULL DEFAULT 'OPEN', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(company_id) REFERENCES companies(company_id), CHECK(openings >= 0), CHECK(min_percentage BETWEEN 0 AND 100), CHECK(max_backlogs >= 0)
);
CREATE TABLE IF NOT EXISTS applications (
 application_id INT AUTO_INCREMENT PRIMARY KEY, candidate_id INT NOT NULL, job_id INT NOT NULL,
 status ENUM('APPLIED','SHORTLISTED','INTERVIEW','SELECTED','OFFERED','JOINED','REJECTED') NOT NULL DEFAULT 'APPLIED',
 applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(candidate_id,job_id),
 FOREIGN KEY(candidate_id) REFERENCES candidates(candidate_id), FOREIGN KEY(job_id) REFERENCES jobs(job_id)
);
CREATE TABLE IF NOT EXISTS interviews (
 interview_id INT AUTO_INCREMENT PRIMARY KEY, application_id INT NOT NULL, round_name VARCHAR(100) NOT NULL,
 scheduled_at DATETIME NOT NULL, mode ENUM('ONLINE','OFFLINE','PHONE') NOT NULL, interviewer VARCHAR(120),
 technical_rating DECIMAL(3,1), communication_rating DECIMAL(3,1), remarks TEXT, result ENUM('PENDING','PASS','FAIL') DEFAULT 'PENDING', notes TEXT,
 FOREIGN KEY(application_id) REFERENCES applications(application_id)
);
CREATE TABLE IF NOT EXISTS offers (
 offer_id INT AUTO_INCREMENT PRIMARY KEY, application_id INT NOT NULL, designation VARCHAR(160) NOT NULL,
 package_lpa DECIMAL(8,2) NOT NULL, offer_date DATE NOT NULL, joining_date DATE, status ENUM('PENDING','ACCEPTED','DECLINED','JOINED') DEFAULT 'PENDING',
 FOREIGN KEY(application_id) REFERENCES applications(application_id)
);
CREATE TABLE IF NOT EXISTS placements (
 placement_id INT AUTO_INCREMENT PRIMARY KEY, application_id INT NOT NULL UNIQUE, company_id INT NOT NULL,
 designation VARCHAR(160) NOT NULL, final_package_lpa DECIMAL(8,2) NOT NULL, actual_joining_date DATE,
 joining_status ENUM('JOINED','PENDING','NOT_JOINED') NOT NULL DEFAULT 'PENDING', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(application_id) REFERENCES applications(application_id), FOREIGN KEY(company_id) REFERENCES companies(company_id)
);
